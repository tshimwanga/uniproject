-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: MARIAGE
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ADRESSE`
--

DROP TABLE IF EXISTS `ADRESSE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ADRESSE` (
  `id_adresse` varchar(12) NOT NULL,
  `pays` varchar(13) NOT NULL,
  `coo_lattitude` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `coo_longitude` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `code_postal` int NOT NULL,
  `ville` varchar(16) NOT NULL,
  `rue` varchar(30) NOT NULL,
  `numero` int NOT NULL,
  PRIMARY KEY (`id_adresse`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ADRESSE`
--

LOCK TABLES `ADRESSE` WRITE;
/*!40000 ALTER TABLE `ADRESSE` DISABLE KEYS */;
INSERT INTO `ADRESSE` VALUES ('AD01','Belgique','25412','874512',5000,'Namur','Avenue Reine Astrid',19),('AD02','Cameroun','54624','94625',10523,'Bafang','Rue Napoleon',5),('AD03','Belgique','46978','96443',4000,'Liege','Sainte Anne',78),('AD04','Belgique','69978','96543',7000,'Mons','de lange',63),('AD05','France','35478',NULL,75850,'Paris','des champs',63),('AD06','Belgique','8163','8880',4000,'namur','moulins',360),('AD07','Belgique','5541','4644',40000,'namur','salzine',45);
/*!40000 ALTER TABLE `ADRESSE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BOUTIQUE`
--

DROP TABLE IF EXISTS `BOUTIQUE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BOUTIQUE` (
  `numero` varchar(255) NOT NULL,
  PRIMARY KEY (`numero`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BOUTIQUE`
--

LOCK TABLES `BOUTIQUE` WRITE;
/*!40000 ALTER TABLE `BOUTIQUE` DISABLE KEYS */;
INSERT INTO `BOUTIQUE` VALUES ('BO01'),('BO02'),('BO03'),('BO04'),('BO05');
/*!40000 ALTER TABLE `BOUTIQUE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CADRE`
--

DROP TABLE IF EXISTS `CADRE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CADRE` (
  `matricule_per` varchar(15) NOT NULL,
  `RESPONSABLE` varchar(15) DEFAULT NULL,
  `GERANT` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`matricule_per`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CADRE`
--

LOCK TABLES `CADRE` WRITE;
/*!40000 ALTER TABLE `CADRE` DISABLE KEYS */;
INSERT INTO `CADRE` VALUES ('PE01','Menie','Vic'),('PE02','Melissa','Bruge'),('PE03','Mirla','Ulrich'),('PE04','Melania','Rodrigue');
/*!40000 ALTER TABLE `CADRE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENT`
--

DROP TABLE IF EXISTS `CLIENT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CLIENT` (
  `code_client` varchar(12) NOT NULL,
  PRIMARY KEY (`code_client`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENT`
--

LOCK TABLES `CLIENT` WRITE;
/*!40000 ALTER TABLE `CLIENT` DISABLE KEYS */;
INSERT INTO `CLIENT` VALUES ('CL01'),('CL02'),('CL03'),('CL04'),('CL05'),('CL06'),('CL09');
/*!40000 ALTER TABLE `CLIENT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COMMANDE`
--

DROP TABLE IF EXISTS `COMMANDE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `COMMANDE` (
  `code_commande` varchar(16) NOT NULL,
  `date_commande` date NOT NULL,
  `date_livraison_prevue` date NOT NULL,
  `date_livraison_effective` date DEFAULT NULL,
  `statut_commande` varchar(15) NOT NULL,
  `code_client` varchar(12) NOT NULL,
  PRIMARY KEY (`code_commande`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COMMANDE`
--

LOCK TABLES `COMMANDE` WRITE;
/*!40000 ALTER TABLE `COMMANDE` DISABLE KEYS */;
INSERT INTO `COMMANDE` VALUES ('CO01','2023-03-27','2023-04-10',NULL,'En cours','CL02'),('CO02','2023-04-01','2023-04-09',NULL,'En préparation','CL04'),('CO03','2023-03-27','2023-04-04',NULL,'En cours','CL02'),('CO04','2023-02-27','2023-03-10','2023-03-11','Livré','CL05'),('CO05','2023-03-24','2023-04-05',NULL,'Expédié','CL03'),('CO06','2023-04-28','2023-05-05',NULL,'Expédié','CL01'),('CO07','2023-05-08','2023-05-05',NULL,'Expédié','CL03');
/*!40000 ALTER TABLE `COMMANDE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `COMPTA_ACHAT`
--

DROP TABLE IF EXISTS `COMPTA_ACHAT`;
/*!50001 DROP VIEW IF EXISTS `COMPTA_ACHAT`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `COMPTA_ACHAT` AS SELECT 
 1 AS `code_barre`,
 1 AS `type`,
 1 AS `prix`,
 1 AS `date_livraison_effective`,
 1 AS `robe_code_barre`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `CONTIENT`
--

DROP TABLE IF EXISTS `CONTIENT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CONTIENT` (
  `numero` varchar(255) NOT NULL,
  `code_barre` varchar(15) NOT NULL,
  `date_entree` date NOT NULL,
  PRIMARY KEY (`numero`,`code_barre`,`date_entree`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CONTIENT`
--

LOCK TABLES `CONTIENT` WRITE;
/*!40000 ALTER TABLE `CONTIENT` DISABLE KEYS */;
INSERT INTO `CONTIENT` VALUES ('BO01','0000001','2022-06-30'),('BO02','0000003','2023-03-30'),('BO03','0000005','2023-02-28'),('BO04','0000004','2022-11-30'),('BO05','0000002','2023-01-30');
/*!40000 ALTER TABLE `CONTIENT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COUTURIER`
--

DROP TABLE IF EXISTS `COUTURIER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `COUTURIER` (
  `matricule_per` varchar(15) NOT NULL,
  PRIMARY KEY (`matricule_per`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COUTURIER`
--

LOCK TABLES `COUTURIER` WRITE;
/*!40000 ALTER TABLE `COUTURIER` DISABLE KEYS */;
INSERT INTO `COUTURIER` VALUES ('PE09'),('PE10'),('PE11');
/*!40000 ALTER TABLE `COUTURIER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EMPRUNT`
--

DROP TABLE IF EXISTS `EMPRUNT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EMPRUNT` (
  `code_emprunt` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `date_emprunt` date NOT NULL,
  `caution` float NOT NULL,
  `date_retour_prevue` date NOT NULL,
  `date_retour_effective` date DEFAULT NULL,
  `code_barre` varchar(15) NOT NULL,
  `date_entree` date NOT NULL,
  `code_client` varchar(12) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `matricule_per` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  PRIMARY KEY (`code_emprunt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EMPRUNT`
--

LOCK TABLES `EMPRUNT` WRITE;
/*!40000 ALTER TABLE `EMPRUNT` DISABLE KEYS */;
INSERT INTO `EMPRUNT` VALUES ('EM01','2023-04-01',500,'2023-04-11',NULL,'0000001','2022-06-30','CL01',''),('EM02','2023-05-08',-1400,'2023-05-23','2023-05-21','0000002','2023-01-30','CL02',NULL),('EM03','2023-05-21',-1400,'2023-06-05','2023-05-21','0000002','2023-01-30','CL01',NULL),('EM04','2023-05-21',-1400,'2023-06-05','2023-05-21','0000002','2023-01-30','CL01',NULL),('EM05','2023-05-21',600,'2023-06-05',NULL,'0000002','2023-01-30','CL01',NULL);
/*!40000 ALTER TABLE `EMPRUNT` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `verification_retour` BEFORE INSERT ON `EMPRUNT` FOR EACH ROW BEGIN
    DECLARE client_code_barre varchar(15);
    DECLARE robe_disponibilite varchar(30);
    SET client_code_barre = NEW.code_barre;
    SELECT disponibilite INTO robe_disponibilite
    FROM ROBE_EMPRUNTEE
    WHERE code_barre = client_code_barre;
    
    IF robe_disponibilite IS NULL THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = "La robe n'appartient pas au client.";
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `ENTREPOT_STOCKAGE`
--

DROP TABLE IF EXISTS `ENTREPOT_STOCKAGE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ENTREPOT_STOCKAGE` (
  `num_stock` varchar(17) NOT NULL,
  `date_de_mise_a_jour` date NOT NULL,
  `statut` varchar(12) NOT NULL,
  `id_adresse` varchar(12) NOT NULL,
  PRIMARY KEY (`num_stock`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ENTREPOT_STOCKAGE`
--

LOCK TABLES `ENTREPOT_STOCKAGE` WRITE;
/*!40000 ALTER TABLE `ENTREPOT_STOCKAGE` DISABLE KEYS */;
INSERT INTO `ENTREPOT_STOCKAGE` VALUES ('ST01','2021-05-14','CRITIQUE','AD01'),('ST02','2021-08-14','NORMAL','AD05'),('ST03','2021-02-10','RECOMMENDER','AD04'),('ST04','2021-05-18','NORMAL','AD02');
/*!40000 ALTER TABLE `ENTREPOT_STOCKAGE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ETABLISSEMENT`
--

DROP TABLE IF EXISTS `ETABLISSEMENT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ETABLISSEMENT` (
  `numero` varchar(20) NOT NULL,
  `nom` varchar(15) NOT NULL,
  `id_adresse` varchar(12) NOT NULL,
  `MAISON_DE_COUTURE` decimal(9,0) DEFAULT NULL,
  `BOUTIQUE` decimal(9,0) DEFAULT NULL,
  PRIMARY KEY (`numero`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ETABLISSEMENT`
--

LOCK TABLES `ETABLISSEMENT` WRITE;
/*!40000 ALTER TABLE `ETABLISSEMENT` DISABLE KEYS */;
INSERT INTO `ETABLISSEMENT` VALUES ('BO01','menie_wedding','AD01',NULL,NULL),('BO02','nana_wedding','AD02',NULL,NULL),('BO03','yando_wedding','AD03',NULL,NULL),('BO04','fotso_wedding','AD04',NULL,NULL),('BO05','bruge_wedding','AD05',NULL,NULL),('MC01','vic_couture','AD01',NULL,NULL),('MC02','menie_couture','AD02',NULL,NULL),('MC03','ulrich_couture','AD03',NULL,NULL),('MC04','ngongo_couture','AD04',NULL,NULL);
/*!40000 ALTER TABLE `ETABLISSEMENT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FOURNISSEUR`
--

DROP TABLE IF EXISTS `FOURNISSEUR`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FOURNISSEUR` (
  `matricule_fourn` varchar(15) NOT NULL,
  PRIMARY KEY (`matricule_fourn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FOURNISSEUR`
--

LOCK TABLES `FOURNISSEUR` WRITE;
/*!40000 ALTER TABLE `FOURNISSEUR` DISABLE KEYS */;
INSERT INTO `FOURNISSEUR` VALUES ('FO01'),('FO02'),('FO03'),('FO04'),('FO05');
/*!40000 ALTER TABLE `FOURNISSEUR` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FOURNIT`
--

DROP TABLE IF EXISTS `FOURNIT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FOURNIT` (
  `code_barre` varchar(15) NOT NULL,
  `date_entree` date NOT NULL,
  `Date` date NOT NULL,
  `matricule_fourn` varchar(15) NOT NULL,
  PRIMARY KEY (`code_barre`,`date_entree`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FOURNIT`
--

LOCK TABLES `FOURNIT` WRITE;
/*!40000 ALTER TABLE `FOURNIT` DISABLE KEYS */;
INSERT INTO `FOURNIT` VALUES ('0000006','2023-04-10','2023-04-01','FO01'),('0000007','2023-04-10','2023-04-01','FO02'),('0000008','2023-04-12','2023-04-04','FO02'),('0000009','2023-04-14','2023-04-05','FO03'),('0000010','2023-04-15','2023-04-06','FO04');
/*!40000 ALTER TABLE `FOURNIT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GERANT`
--

DROP TABLE IF EXISTS `GERANT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GERANT` (
  `matricule_per` varchar(15) NOT NULL,
  PRIMARY KEY (`matricule_per`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GERANT`
--

LOCK TABLES `GERANT` WRITE;
/*!40000 ALTER TABLE `GERANT` DISABLE KEYS */;
INSERT INTO `GERANT` VALUES ('PE13'),('PE14'),('PE15'),('PE16'),('PE17');
/*!40000 ALTER TABLE `GERANT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAISON_DE_COUTURE`
--

DROP TABLE IF EXISTS `MAISON_DE_COUTURE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MAISON_DE_COUTURE` (
  `numero` varchar(15) NOT NULL,
  `matricule_per` varchar(15) NOT NULL,
  PRIMARY KEY (`numero`),
  UNIQUE KEY `SID_MAISO_GERAN_ID` (`matricule_per`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAISON_DE_COUTURE`
--

LOCK TABLES `MAISON_DE_COUTURE` WRITE;
/*!40000 ALTER TABLE `MAISON_DE_COUTURE` DISABLE KEYS */;
INSERT INTO `MAISON_DE_COUTURE` VALUES ('MC01','PE01'),('MC02','PE02'),('MC03','PE03'),('MC04','PE04');
/*!40000 ALTER TABLE `MAISON_DE_COUTURE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MANIPULATION`
--

DROP TABLE IF EXISTS `MANIPULATION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MANIPULATION` (
  `code_manipulation` varchar(15) NOT NULL,
  `duree` decimal(12,0) NOT NULL,
  `date_debut` date NOT NULL,
  `date_fin` date NOT NULL,
  `note` varchar(12) NOT NULL,
  `matricule_per` varchar(15) NOT NULL,
  PRIMARY KEY (`code_manipulation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MANIPULATION`
--

LOCK TABLES `MANIPULATION` WRITE;
/*!40000 ALTER TABLE `MANIPULATION` DISABLE KEYS */;
INSERT INTO `MANIPULATION` VALUES ('MA01',1,'2023-04-18','2023-04-19','.','PE09'),('MA02',3,'2023-04-18','2023-04-19','.','PE10'),('MA03',2,'2023-04-20','2023-04-21','.','PE09'),('MA04',4,'2023-04-25','2023-04-26','.','PE11'),('MA05',2,'2023-04-27','2023-04-28','.','PE11');
/*!40000 ALTER TABLE `MANIPULATION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MODELE`
--

DROP TABLE IF EXISTS `MODELE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MODELE` (
  `type` varchar(15) NOT NULL,
  `prix` decimal(7,0) NOT NULL,
  `marque` varchar(10) NOT NULL,
  `description` varchar(25) NOT NULL,
  PRIMARY KEY (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MODELE`
--

LOCK TABLES `MODELE` WRITE;
/*!40000 ALTER TABLE `MODELE` DISABLE KEYS */;
INSERT INTO `MODELE` VALUES ('Dosnu',500,'Asos','.'),('Droite',400,'Chanel','.'),('Princess',900,'Chanel','.'),('Sirène',800,'Sézane','.');
/*!40000 ALTER TABLE `MODELE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `OPERATION_ROBE`
--

DROP TABLE IF EXISTS `OPERATION_ROBE`;
/*!50001 DROP VIEW IF EXISTS `OPERATION_ROBE`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `OPERATION_ROBE` AS SELECT 
 1 AS `code_barre`,
 1 AS `date_entree`,
 1 AS `type_reajustement`,
 1 AS `note_manipulation`,
 1 AS `nom_maison_couture`,
 1 AS `matricule_gerant`,
 1 AS `matricule_couturier`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `PERSONNE`
--

DROP TABLE IF EXISTS `PERSONNE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PERSONNE` (
  `matricule_per` varchar(15) DEFAULT NULL,
  `matricule_fourn` varchar(15) DEFAULT NULL,
  `code_client` varchar(12) DEFAULT NULL,
  `nom` varchar(19) NOT NULL,
  `adresse_mail` varchar(19) NOT NULL,
  `telephone` decimal(10,0) NOT NULL,
  `id_adresse` varchar(12) NOT NULL,
  UNIQUE KEY `SID_PERSO_PERSO_ID` (`matricule_per`),
  UNIQUE KEY `SID_PERSO_FOURN_ID` (`matricule_fourn`),
  UNIQUE KEY `SID_PERSO_CLIEN_ID` (`code_client`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PERSONNE`
--

LOCK TABLES `PERSONNE` WRITE;
/*!40000 ALTER TABLE `PERSONNE` DISABLE KEYS */;
INSERT INTO `PERSONNE` VALUES (NULL,NULL,'CL01','Albert','albert@gmail.com',467215689,'AD01'),(NULL,NULL,'CL02','Leo','leo@gmail.com',465215987,'AD02'),(NULL,NULL,'CL03','Ngongon','ngongon@gmail.vom',465854719,'AD03'),(NULL,NULL,'CL08','victor','victor@gmail.com',55887744,'AD02'),(NULL,NULL,'CL09','aubry','aubry@gmail.com',6465465,'AD07');
/*!40000 ALTER TABLE `PERSONNE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PERSONNEL`
--

DROP TABLE IF EXISTS `PERSONNEL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PERSONNEL` (
  `matricule_per` varchar(15) NOT NULL,
  `COUTURIER` varchar(15) DEFAULT NULL,
  `CADRE` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`matricule_per`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PERSONNEL`
--

LOCK TABLES `PERSONNEL` WRITE;
/*!40000 ALTER TABLE `PERSONNEL` DISABLE KEYS */;
INSERT INTO `PERSONNEL` VALUES ('PE01',NULL,NULL),('PE02',NULL,NULL);
/*!40000 ALTER TABLE `PERSONNEL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REAJUSTEMENT`
--

DROP TABLE IF EXISTS `REAJUSTEMENT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REAJUSTEMENT` (
  `code_barre` varchar(15) NOT NULL,
  `date_entree` date NOT NULL,
  `code_reajustement` varchar(12) NOT NULL,
  `type` varchar(15) NOT NULL,
  `description` varchar(57) NOT NULL,
  `prix_reajustement` float NOT NULL,
  `numero` varchar(255) NOT NULL,
  PRIMARY KEY (`code_reajustement`,`code_barre`,`date_entree`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REAJUSTEMENT`
--

LOCK TABLES `REAJUSTEMENT` WRITE;
/*!40000 ALTER TABLE `REAJUSTEMENT` DISABLE KEYS */;
INSERT INTO `REAJUSTEMENT` VALUES ('0000003','2023-03-30','REA01','customisation','rajout',190,'MC01');
/*!40000 ALTER TABLE `REAJUSTEMENT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REMBOURSEMENT`
--

DROP TABLE IF EXISTS `REMBOURSEMENT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REMBOURSEMENT` (
  `numero` varchar(20) NOT NULL,
  `code_client` varchar(12) NOT NULL,
  `code_commande` varchar(16) NOT NULL,
  `date_remboursement` date DEFAULT NULL,
  `montant` float DEFAULT NULL,
  PRIMARY KEY (`code_commande`,`numero`,`code_client`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REMBOURSEMENT`
--

LOCK TABLES `REMBOURSEMENT` WRITE;
/*!40000 ALTER TABLE `REMBOURSEMENT` DISABLE KEYS */;
INSERT INTO `REMBOURSEMENT` VALUES ('BO02','CL02','CO01',NULL,800);
/*!40000 ALTER TABLE `REMBOURSEMENT` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `remboursement_client1` BEFORE INSERT ON `REMBOURSEMENT` FOR EACH ROW BEGIN
    DECLARE v_code_commande VARCHAR(10);
    SELECT code_commande
    INTO v_code_commande
    FROM COMMANDE
    WHERE code_commande = NEW.code_commande
        AND code_client = NEW.code_client;
    IF v_code_commande IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = "Vous ne pouvez pas demander un remboursement pour cette commande car vous ne l'avez pas commandé";
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `RESPONSABLE`
--

DROP TABLE IF EXISTS `RESPONSABLE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RESPONSABLE` (
  `numero` varchar(15) NOT NULL,
  `matricule_per` varchar(15) NOT NULL,
  PRIMARY KEY (`numero`),
  UNIQUE KEY `SID_RESPO_CADRE_ID` (`matricule_per`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RESPONSABLE`
--

LOCK TABLES `RESPONSABLE` WRITE;
/*!40000 ALTER TABLE `RESPONSABLE` DISABLE KEYS */;
INSERT INTO `RESPONSABLE` VALUES ('BO01','PE01'),('BO02','PE02');
/*!40000 ALTER TABLE `RESPONSABLE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ROBE`
--

DROP TABLE IF EXISTS `ROBE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ROBE` (
  `code_barre` varchar(15) NOT NULL,
  `date_entree` date NOT NULL,
  `date_confection` date NOT NULL,
  `matricule_four` varchar(15) NOT NULL,
  `historique` char(1) DEFAULT NULL,
  `a_num_stock` varchar(17) NOT NULL,
  `ROBE_ACHETEE` varchar(15) DEFAULT NULL,
  `ROBE_EMPRUNTEE` varchar(15) DEFAULT NULL,
  `type` varchar(15) NOT NULL,
  PRIMARY KEY (`code_barre`,`date_entree`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ROBE`
--

LOCK TABLES `ROBE` WRITE;
/*!40000 ALTER TABLE `ROBE` DISABLE KEYS */;
INSERT INTO `ROBE` VALUES ('0000002','2023-01-30','2022-12-29','FO03','e','ST04',NULL,NULL,'Dosnu'),('0000003','2023-03-30','2023-02-27','FO02','c','ST03',NULL,NULL,'Princesse'),('0000004','2022-11-30','2022-08-30','FO05','v','ST01',NULL,NULL,'Sirène'),('0000005','2023-02-28','2023-01-31','FO03','z','ST04',NULL,NULL,'Droite');
/*!40000 ALTER TABLE `ROBE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ROBE_ACHETEE`
--

DROP TABLE IF EXISTS `ROBE_ACHETEE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ROBE_ACHETEE` (
  `code_barre` varchar(15) NOT NULL,
  `date_entree` date NOT NULL,
  `code_commande` varchar(16) NOT NULL,
  PRIMARY KEY (`code_barre`,`date_entree`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ROBE_ACHETEE`
--

LOCK TABLES `ROBE_ACHETEE` WRITE;
/*!40000 ALTER TABLE `ROBE_ACHETEE` DISABLE KEYS */;
INSERT INTO `ROBE_ACHETEE` VALUES ('0000003','2023-03-30','CO03'),('0000004','2022-11-30','CO01');
/*!40000 ALTER TABLE `ROBE_ACHETEE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ROBE_EMPRUNTEE`
--

DROP TABLE IF EXISTS `ROBE_EMPRUNTEE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ROBE_EMPRUNTEE` (
  `code_barre` varchar(15) NOT NULL,
  `date_entree` date NOT NULL,
  `disponibilite` varchar(30) NOT NULL,
  PRIMARY KEY (`code_barre`,`date_entree`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ROBE_EMPRUNTEE`
--

LOCK TABLES `ROBE_EMPRUNTEE` WRITE;
/*!40000 ALTER TABLE `ROBE_EMPRUNTEE` DISABLE KEYS */;
INSERT INTO `ROBE_EMPRUNTEE` VALUES ('0000001','2022-06-30',''),('0000002','2023-01-30','prise');
/*!40000 ALTER TABLE `ROBE_EMPRUNTEE` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `emprunt_robe` BEFORE INSERT ON `ROBE_EMPRUNTEE` FOR EACH ROW BEGIN
    DECLARE robe_code_barre varchar(15);
    DECLARE robe_date_retour_effective date;
    SET robe_code_barre = NEW.code_barre; 
    SELECT date_retour_effective INTO robe_date_retour_effective
    FROM EMPRUNT
    WHERE code_barre = robe_code_barre;  
    IF robe_date_retour_effective IS NULL THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = "La robe n'a pas de date de retour effective et ne peut pas être empruntée.";
    END IF;  
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Temporary view structure for view `apercu_robe`
--

DROP TABLE IF EXISTS `apercu_robe`;
/*!50001 DROP VIEW IF EXISTS `apercu_robe`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `apercu_robe` AS SELECT 
 1 AS `code_barre`,
 1 AS `type`,
 1 AS `prix`,
 1 AS `disponibilite`,
 1 AS `statut_commande`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `contenir`
--

DROP TABLE IF EXISTS `contenir`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contenir` (
  `code_manipulation` varchar(15) NOT NULL,
  `nombre` decimal(15,0) NOT NULL,
  `code_reajustement` varchar(12) NOT NULL,
  `code_barre` varchar(15) NOT NULL,
  `date_entree` date NOT NULL,
  PRIMARY KEY (`code_manipulation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contenir`
--

LOCK TABLES `contenir` WRITE;
/*!40000 ALTER TABLE `contenir` DISABLE KEYS */;
INSERT INTO `contenir` VALUES ('MA01',7,'REA01','0000003','2023-03-30');
/*!40000 ALTER TABLE `contenir` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `info_client`
--

DROP TABLE IF EXISTS `info_client`;
/*!50001 DROP VIEW IF EXISTS `info_client`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `info_client` AS SELECT 
 1 AS `code_client`,
 1 AS `nom`,
 1 AS `adresse_mail`,
 1 AS `telephone`,
 1 AS `pays`,
 1 AS `ville`,
 1 AS `rue`,
 1 AS `numero`*/;
SET character_set_client = @saved_cs_client;

--
-- Dumping events for database 'MARIAGE'
--

--
-- Dumping routines for database 'MARIAGE'
--

--
-- Final view structure for view `COMPTA_ACHAT`
--

/*!50001 DROP VIEW IF EXISTS `COMPTA_ACHAT`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `COMPTA_ACHAT` AS select `ROBE_ACHETEE`.`code_barre` AS `code_barre`,`MODELE`.`type` AS `type`,`MODELE`.`prix` AS `prix`,`COMMANDE`.`date_livraison_effective` AS `date_livraison_effective`,`ROBE`.`code_barre` AS `robe_code_barre` from (((`ROBE` join `MODELE` on((`ROBE`.`type` = `MODELE`.`type`))) join `ROBE_ACHETEE` on((`ROBE`.`code_barre` = `ROBE_ACHETEE`.`code_barre`))) join `COMMANDE` on((`ROBE_ACHETEE`.`code_commande` = `COMMANDE`.`code_commande`))) where (`COMMANDE`.`statut_commande` = 'livré') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `OPERATION_ROBE`
--

/*!50001 DROP VIEW IF EXISTS `OPERATION_ROBE`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `OPERATION_ROBE` AS select `REAJUSTEMENT`.`code_barre` AS `code_barre`,`REAJUSTEMENT`.`date_entree` AS `date_entree`,`REAJUSTEMENT`.`type` AS `type_reajustement`,`MANIPULATION`.`note` AS `note_manipulation`,`ETABLISSEMENT`.`nom` AS `nom_maison_couture`,`GERANT`.`matricule_per` AS `matricule_gerant`,`COUTURIER`.`matricule_per` AS `matricule_couturier` from ((((((`REAJUSTEMENT` join `contenir` on(((`REAJUSTEMENT`.`code_reajustement` = `contenir`.`code_reajustement`) and (`REAJUSTEMENT`.`code_barre` = `contenir`.`code_barre`) and (`REAJUSTEMENT`.`date_entree` = `contenir`.`date_entree`)))) join `MANIPULATION` on((`contenir`.`code_manipulation` = `MANIPULATION`.`code_manipulation`))) join `MAISON_DE_COUTURE` on((`REAJUSTEMENT`.`numero` = `MAISON_DE_COUTURE`.`numero`))) join `GERANT` on((`MAISON_DE_COUTURE`.`matricule_per` = `GERANT`.`matricule_per`))) join `ETABLISSEMENT` on((`MAISON_DE_COUTURE`.`numero` = `ETABLISSEMENT`.`MAISON_DE_COUTURE`))) join `COUTURIER` on((`MANIPULATION`.`matricule_per` = `COUTURIER`.`matricule_per`))) group by `REAJUSTEMENT`.`code_barre`,`REAJUSTEMENT`.`date_entree`,`REAJUSTEMENT`.`type`,`MANIPULATION`.`note`,`ETABLISSEMENT`.`nom`,`GERANT`.`matricule_per`,`COUTURIER`.`matricule_per` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `apercu_robe`
--

/*!50001 DROP VIEW IF EXISTS `apercu_robe`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `apercu_robe` AS select `ROBE`.`code_barre` AS `code_barre`,`ROBE`.`type` AS `type`,`MODELE`.`prix` AS `prix`,`ROBE_EMPRUNTEE`.`disponibilite` AS `disponibilite`,`COMMANDE`.`statut_commande` AS `statut_commande` from ((((`ROBE` join `ROBE_ACHETEE` on((`ROBE`.`code_barre` = `ROBE_ACHETEE`.`code_barre`))) join `MODELE` on((`ROBE`.`type` = `MODELE`.`type`))) join `ROBE_EMPRUNTEE` on((`ROBE`.`code_barre` = `ROBE_EMPRUNTEE`.`code_barre`))) join `COMMANDE` on((`ROBE_ACHETEE`.`code_commande` = `COMMANDE`.`code_commande`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `info_client`
--

/*!50001 DROP VIEW IF EXISTS `info_client`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `info_client` AS select `PERSONNE`.`code_client` AS `code_client`,`PERSONNE`.`nom` AS `nom`,`PERSONNE`.`adresse_mail` AS `adresse_mail`,`PERSONNE`.`telephone` AS `telephone`,`ADRESSE`.`pays` AS `pays`,`ADRESSE`.`ville` AS `ville`,`ADRESSE`.`rue` AS `rue`,`ADRESSE`.`numero` AS `numero` from (`PERSONNE` join `ADRESSE` on((`PERSONNE`.`id_adresse` = `ADRESSE`.`id_adresse`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
CREATE USER 'compta'@'%'IDENTIFIED BY '1234';
GRANT ALL PRIVILEGES ON MARIAGE.* TO 'compta'@'%';
CREATE USER 'client'@'%'IDENTIFIED BY '12345';

GRANT ALL PRIVILEGES
ON MARIAGE.`ADRESSE` TO 'client'@'%';
GRANT ALL PRIVILEGES
ON MARIAGE.`BOUTIQUE` TO 'client'@'%';
GRANT ALL PRIVILEGES
ON MARIAGE.`CADRE` TO 'client'@'%';
GRANT ALL PRIVILEGES
ON MARIAGE.`CLIENT` TO 'client'@'%';
GRANT ALL PRIVILEGES
ON MARIAGE.`COMMANDE` TO 'client'@'%';
GRANT ALL PRIVILEGES
ON MARIAGE.`CONTIENT` TO 'client'@'%';
GRANT ALL PRIVILEGES
ON MARIAGE.`COUTURIER` TO 'client'@'%';
GRANT ALL PRIVILEGES
ON MARIAGE.`EMPRUNT` TO 'client'@'%';
GRANT ALL PRIVILEGES
ON MARIAGE.`ENTREPOT_STOCKAGE` TO 'client'@'%';
GRANT ALL PRIVILEGES
ON MARIAGE.`ETABLISSEMENT` TO 'client'@'%';
GRANT ALL PRIVILEGES
ON MARIAGE.`FOURNISSEUR` TO 'client'@'%';
GRANT ALL PRIVILEGES
ON MARIAGE.`FOURNIT` TO 'client'@'%';
GRANT ALL PRIVILEGES
ON MARIAGE.`GERANT` TO 'client'@'%';
GRANT ALL PRIVILEGES
ON MARIAGE.`MAISON_DE_COUTURE` TO 'client'@'%';
GRANT ALL PRIVILEGES
ON MARIAGE.`MANIPULATION` TO 'client'@'%';
GRANT ALL PRIVILEGES
ON MARIAGE.`MODELE` TO 'client'@'%';
GRANT ALL PRIVILEGES
ON MARIAGE.`PERSONNE` TO 'client'@'%';
GRANT ALL PRIVILEGES
ON MARIAGE.`PERSONNEL` TO 'client'@'%';
GRANT ALL PRIVILEGES
ON MARIAGE.`REAJUSTEMENT` TO 'client'@'%';
GRANT ALL PRIVILEGES
ON MARIAGE.`REMBOURSEMENT` TO 'client'@'%';
GRANT ALL PRIVILEGES
ON MARIAGE.`ROBE` TO 'client'@'%';
GRANT ALL PRIVILEGES
ON MARIAGE.`ROBE_ACHETEE` TO 'client'@'%';
GRANT ALL PRIVILEGES
ON MARIAGE.`ROBE_EMPRUNTEE` TO 'client'@'%';

-- Dump completed on 2023-05-21 21:23:35
