from datetime import datetime,timedelta
import mysql.connector
from random import randint
import sys

a=""

while a not in ["client", "comptable"]:
  a=input("etes vous un client ou un comptable?\n")

if a=="client":

  mydb = mysql.connector.connect(
    host="localhost",
    port="3300",
    user="client",
    password="12345",
    database="MARIAGE"
  )
  
elif a=="comptable":
  utilsateur = input("Veuillez insérer votre nom d'utilisateur de comptable de la base de donnée\n")
  mot_de_pass = input("Veuillez insérer votre mot de passe\n")
  mydb = mysql.connector.connect(
    host="localhost",
    port="3300",
    user=utilsateur,
    password=mot_de_pass,
    database="MARIAGE"
  )

mycursor = mydb.cursor()



def client_account_creation(data_client):
    # cree un compte en inserant une ligne dans la table client
  
    #if data base connection is ok
    cursor =mydb.cursor()
    try :
        if mydb:
          
          #  ID = data_client[code_client]

            query1 = ("INSERT INTO CLIENT"
               "(code_client)"
               "VALUES (%(code_client)s)")

            data_user1 = {
            'code_client': data_client["code_client"],
            }

            cursor.execute(query1, data_user1)

            # Make sure data is committed to the database
            mydb.commit()
            
            ##########################################################
            #To be inserted into Client Account
            add_client = ("INSERT INTO PERSONNE "
                          "(code_client, nom, adresse_mail, telephone, id_adresse ) "
                          "VALUES (%(code_client)s, %(nom)s, %(adresse_mail)s, %(telephone)s, %(id_adresse)s )")

            cursor.execute(add_client, data_client)
            mydb.commit()
            
        return 1
          

    except mysql.connector.Error as err:
        if err.errno == errorcode.ER_ACCESS_DENIED_ERROR:
            print("Something is wrong with the information you've provided")
        elif err.errno == errorcode.ER_BAD_DB_ERROR:
            print("Database does not exist")
        else:
            print(err)
    else:

        cursor.close()
        mydb.close()
        return cursor.lastrowid
      
def register():
    # this function is used to create a new
    # customer account

    #var cl : dictionnaire
    cl ={"matricule_per" : "","matricule_fourn" : "","code_client" : "", "nom": "", "adresse_mail": "","telephone": "", "id_adresse": "" }

    #to be inserted into user account table
    acc = {"user_name": "", "password":"","user_type":"", "date_creation":"","date_updation":""}
    start = 0
    while (   (cl["matricule_per"].strip() == "" 
           or cl["matricule_fourn"].strip() == "" 
           or cl["code_client"].strip() == "" 
           or cl["nom"].strip() == "" 
           or cl["adresse_mail"].strip() == "" 
           or cl["telephone"].strip() ==""
           or cl["id_adresse"].strip() =="") and (start == 0) ):

        
        print(" Creation d'un Nouveau Compte Client : ")
        print("\nEntrez vos informations: les champs contenant (*) sont obligatoires \n")
       
        mycursor.execute("SELECT code_client FROM PERSONNE ORDER BY code_client DESC LIMIT 1")
        result3 = mycursor.fetchall()
        sep= result3[0][0].split("0")
        fin= int(sep[1]) +1
        final= sep[0] +"0"+str(fin)
     
        cl["code_client"] = final
        cl["nom"] = input("(*) Nom : ")
        cl["adresse_mail"] = input("(*) adresse_mail:")
        cl["telephone"] = input( "(*) telephone: " )
        
        print(" Création de votre adresse : ")
        
        #créer un curseur de base de données pour effectuer des opérations SQL
        
        cursor =mydb.cursor()
        
         #créer un curseur de base de données pour effectuer des opérations SQL
        cur = mydb.cursor()
        
        mycursor.execute("SELECT id_adresse FROM ADRESSE ORDER BY id_adresse DESC LIMIT 1")
        AD_result3 = mycursor.fetchall()
        AD_sep= AD_result3[0][0].split("0")
        AD_fin= int(AD_sep[1]) +1
        AD_final= AD_sep[0] +"0"+str(AD_fin)
        
        ad ={"id_adresse" : "","pays" : "","coo_lattitude" : "", "coo_longitude": "", "code_postal": "","ville": "", "rue": "", "numero": "" }

        # Acquisition des donnees
        ad["id_adresse"]= AD_final
        ad["pays"]= input("Entre votre Pays : ")
        ad["coo_lattitude"]= randint(1000, 10000)
        ad["coo_longitude"]= randint(1000, 10000)
        ad["code_postal"]=  input("Entre le code postal : ")
        ad["ville"]= input("Entre le nom de votre ville : ")
        ad["rue"]= input("Entre le nom de votre rue : ")
        ad["numero"]= input("Entre le numero de votre rue : ")
          
        
        #exécuter le curseur avec la méthode execute() et transmis la requête SQL
        add_adresse = ("INSERT INTO ADRESSE "
                          "(id_adresse, pays, coo_lattitude, coo_longitude, code_postal,ville, rue, numero ) "
                          "VALUES (%(id_adresse)s, %(pays)s, %(coo_lattitude)s, %(coo_longitude)s, %(code_postal)s,%(ville)s,%(rue)s,%(numero)s )")

        cur.execute(add_adresse, ad)
        mydb.commit()
        
      
        cl["id_adresse"] = AD_final
        
    
       #confirmer ou annuler la creation du compte      
        print("\nVoullez-vous confirmer la creation de ce compte? (verifiez vos informations)\n  ")
        ch = input("\n pressez 'y'  pour confirmer et une autre touche pour annuler : ")
        if(ch == 'y'):
            #envoyez le dictionnaire cl  a la fonction qui permet d ajouter un client dans la BD
            row = client_account_creation(cl)
            if (row ==1):
                print( "\n\033[1m compte creé avec succès et votre code client est ! \033[0m \n"+final)
                start = 1
                
            else :
                print( "\n\033[1m echec de la creation du compte ! \033[0m \n")
                start = 1
     
def commande():
  mycursor.execute("SELECT type FROM ROBE")

  result1 = mycursor.fetchall()
  
  a = " "
  while (a not in ["Droite", "Sirène", "Princesse", "Dosnu"]):
    a=input("entrer le type de votre robe ex (Droite, Sirène, Princesse, Dosnu)\n")
    if a not in ["Droite", "Sirène", "Princesse", "Dosnu"]:
      print("nom incorrect")
   
  #b=input("entrez votre code client ex (CL01, CL02, etc...)\n")

  
  print ("\n")
  mycursor.execute("SELECT code_commande FROM COMMANDE ORDER BY code_commande DESC LIMIT 1")
  result3 = mycursor.fetchall()
  sep= result3[0][0].split("0")
  fin= int(sep[1]) +1
  final= sep[0] +"0"+str(fin)
  
  if ("{}".format(a) ,) in result1:
    mycursor.execute("SELECT code_barre, date_entree FROM ROBE WHERE type='{}'".format(a))
    result2= mycursor.fetchall()
    code=result2[0][0]
    date=result2[0][1]
    mycursor.execute("INSERT INTO `ROBE_ACHETEE` VALUES ('{}','{}','{}')".format(code, date, final))
    date_actuelle = datetime.strptime(datetime.now().strftime('%Y-%m-%d'), '%Y-%m-%d').date()
    date_future = date_actuelle + timedelta(days=15)
    mycursor.execute("INSERT INTO `COMMANDE` VALUES ('{}','{}','{}',NULL,'Expédié','{}')".format(final, date_actuelle, date_future, code_client))
    mycursor.execute("UPDATE `ROBE` SET `historique` = 'v' WHERE `code_barre`='{}' AND `date_entree`='{}'".format(code, date))

    mydb.commit()
    mycursor.close()

def emprunt():
    
    mycursor = mydb.cursor() #créer la connexion avec la bd
    mycursor.execute("SELECT code_emprunt FROM EMPRUNT ORDER BY code_emprunt DESC LIMIT 1") #incrementer le code emprunt
    result7 = mycursor.fetchall()
    sep= result7[0][0].split("0")
    fin= int(sep[1]) +1
    ID_emprunt= sep[0] +"0"+str(fin)

    date = datetime.strptime(datetime.now().strftime('%Y-%m-%d'), '%Y-%m-%d').date()

    date_return_prevue = date + timedelta(days=15)  
    
    cb_robe= input("veuillez saisir le code barre de la robe que vous souhaitez emprunter:")

    date_robe= input("veuillez saisir la date d'entrée de la robe que vous souhaitez emprunter:")


    mycursor.execute("""SELECT * FROM ROBE WHERE code_barre = %s and date_entree = %s and historique='d' """, (cb_robe, date_robe)) #verification si la robe que l'on souhaite emprunter est dispo

    robe_isthere = mycursor.fetchall()

    if robe_isthere:
          mycursor.execute("SELECT prix FROM MODELE WHERE type in (SELECT type FROM ROBE where code_barre=%s and date_entree=%s ) ", (cb_robe, date_robe)) #calculer la caution 

          price_robe=mycursor.fetchall()[0]

          caution= float(price_robe[0]) +(float(price_robe[0]))/5.0
          if code_client.startswith('C'):
          
            mycursor.execute("INSERT INTO EMPRUNT "
                          "(code_emprunt, date_emprunt, caution, date_retour_prevue, date_retour_effective, code_barre, date_entree,code_client,matricule_per) "
                          "VALUES (%s, %s, %s, %s, %s, %s, %s,%s,%s)",
                          (ID_emprunt, date, caution, date_return_prevue, None, cb_robe, date_robe,code_client, None))
            mydb.commit()

          else:
            mycursor.execute("INSERT INTO EMPRUNT "
                          "(code_emprunt, date_emprunt, caution, date_retour_prevue, date_retour_effective, code_barre, date_entree,code_client,matricule_per) "
                          "VALUES (%s, %s, %s, %s, %s, %s, %s,%s,%s)",
                          (ID_emprunt, date, caution, date_return_prevue, None, cb_robe, date_robe,None,code_client))
            mydb.commit()
          
          mycursor.execute("""UPDATE ROBE SET historique='e'
                            WHERE  code_barre= %s and date_entree =%s """, (cb_robe, date_robe))
          
          mydb.commit()
          mycursor.execute("""SELECT * FROM ROBE_EMPRUNTEE WHERE code_barre = %s and date_entree = %s """, (cb_robe, date_robe)) #verification si la robe que l'on souhaite emprunter est dispo

          robee_isthere = mycursor.fetchall()
          if robee_isthere:
             mycursor.execute("""UPDATE ROBE_EMPRUNTEE SET disponibilite='prise'
                            WHERE  code_barre= %s and date_entree =%s """, (cb_robe, date_robe))
             mydb.commit()   
          else:
             mycursor.execute("INSERT INTO ROBE_EMPRUNTEE "
                          "( code_barre, date_entree,disponibilite) "
                          "VALUES (%s, %s,'prise')",
                          (cb_robe, date_robe))
          
             mydb.commit()

          print('votre emprunt a été effectué avec succès')

    else:
         print("Le code barre ou la date d'entrée a été mal saisie veuillez réessayer ou sinon la robe n'est pas disponible")
         
def remboursement():
  mycursor = mydb.cursor()
  mycursor.execute("SELECT code_client FROM COMMANDE;")
  a= input("entrez votre code client ex (CL01, CL02, etc...)\n")
  result5 = mycursor.fetchall()
  print(result5)
  
  if ("{}".format(a) ,) in result5:   
    b= input("entrer la date à la quel la commande à été effectuer")
    mycursor.execute("SELECT code_commande FROM COMMANDE WHERE date_commande='{}'".format(b))
    code_commande = mycursor.fetchone()
    code_commande = code_commande[0]
    

    mycursor.execute("SELECT code_barre FROM ROBE_ACHETEE WHERE code_commande='{}'".format(code_commande))
    barre= mycursor.fetchone()
    barre = barre[0]
    

    mycursor.execute("SELECT date_entree FROM ROBE_ACHETEE WHERE code_commande='{}'".format(code_commande))
    entree= mycursor.fetchone()
    entree = entree[0]
    

    mycursor.execute("UPDATE ROBE SET historique = 'd' WHERE code_barre = '{}'AND date_entree = '{}'".format(barre, entree))
    mycursor.execute("DELETE FROM ROBE_ACHETEE WHERE code_commande='{}'".format(code_commande))
    mycursor.execute("SELECT numero FROM REMBOURSEMENT ORDER BY numero DESC LIMIT 1")
    result8 = mycursor.fetchall()
    sep= result8[0][0].split("0")
    fin= int(sep[1]) + 1
    final= sep[0] +"0"+str(fin)
    
    mycursor.execute("INSERT INTO REMBOURSEMENT VALUES ('{}','{}','{}',NULL,NULL)".format(final,a,code_commande))
    
    mydb.commit()
    mycursor.close()

def retour_emprunt():
    cb_robe= input("veuillez saisir le code barre de la robe que vous souhaitez retourner:")

    date_robe= input("veuillez saisir la date d'entrée de la robe que vous souhaitez retourner:")


    mycursor.execute("""SELECT * FROM EMPRUNT WHERE code_barre = %s and date_entree = %s  """, (cb_robe, date_robe)) #verification si la robe rendu est bien celle emprunté
    robe_isthere = mycursor.fetchall()

    date_really = datetime.now().strftime('%Y-%m-%d')

   
    if robe_isthere:

      rendu= input("venez vous rendre la robe ? Répondez par OUI ou NON si vous l'avez perdu ou endommagé:")

    
      if rendu== "OUI":

        
          mycursor.execute("SELECT caution FROM EMPRUNT WHERE code_barre = %s and date_entree = %s  """, (cb_robe, date_robe))

          prix=mycursor.fetchall()[0]

          mycursor.execute("SELECT prix FROM MODELE WHERE type in (SELECT type FROM ROBE where code_barre=%s and date_entree=%s ) ", (cb_robe, date_robe)) #calculer la caution 

          price_robe=mycursor.fetchall()[0]

          really_price= (prix[0])-float(price_robe[0])

          mycursor.execute("""UPDATE EMPRUNT SET date_retour_effective = %s, caution=%s 
                            WHERE  code_barre= %s and date_entree =%s """, (date_really,really_price,cb_robe, date_robe))
      
          
          mydb.commit()

      
          mycursor.execute("""UPDATE ROBE_EMPRUNTEE SET disponibilite = "disponible" 
                            WHERE  code_barre= %s and date_entree =%s """, (cb_robe, date_robe))
      
          
          mydb.commit()

          mycursor.execute("""UPDATE ROBE SET historique = "d"
                            WHERE  code_barre= %s and date_entree =%s """, (cb_robe, date_robe))
          
          mydb.commit()


          print(" Voici votre argent, Nous espérons que le mariage s'est bien passé et que vous ne reviendrai plus sauf pour un proche ;)")

        
      else:
        print("comme vous avez abimé ou perdu la robe la caution ne vous sera malheureusement pas rendu")

        mycursor.execute("""UPDATE ROBE SET historique = "p"
                            WHERE  code_barre= %s and date_entree =%s """, (cb_robe, date_robe))
      
        mydb.commit() 

        
    else:
       print("Le code de barre ou la date de la robe a été mal saisi ou sinon cette robe n'est pas la nôtre")

def client_data():
  #code_client = input("please enter your id_number : ")
  mycursor = mydb.cursor()

  menu_principal3=True
  while menu_principal:
    print("which operation do you want to perform ? ")
    print("1 : show client information")
    print("2 : update client data")
    print("3 : delete client data")
    print("4 : vers le menu precendent")
    num = int(input("please choose your operation : "))

    while num not in [1,2,3,4] :
        num = int(input("sorry invalid number : please choose a number between 1 and 3"))

    if num == 1 :
      mycursor = mydb.cursor()
      mycursor.execute("SELECT * FROM PERSONNE WHERE code_client = %(id)s", {'id': code_client})
      data = mycursor.fetchone()
      if (code_client in data) :
        print("Client information :")
        print("code_client: "+data[2])
        print("name: "+data[3])
        print("Address: "+data[4])
        print("telephone: "+str(data[5]))
        print("id_address: "+data[6])
      else :
        print("sory but you are not yet register in our store")
      
    elif num == 2:
      # update client data
      nom = input(" Enter client's new name: ")
      adresse_mail = input(" Enter client's new address: ")
      telephone = input(" Enter client's new phone number: ")
      id_adresse = input(" Enter client new id_address: ")
      mycursor.execute("UPDATE PERSONNE SET nom = %(nom)s, adresse_mail = %(adresse_mail)s, telephone = %(telephone)s, id_adresse = %(id_adresse)s WHERE code_client = %(code_client)s", {'nom': nom, 'adresse_mail': adresse_mail, 'telephone': telephone, 'id_adresse': id_adresse, 'code_client': code_client})
      mydb.commit()
      print("update was successfull")


    elif num == 3:
    # Delete client 
      confirm = input("Are you sure you want to delete the client with data: " + str(code_client) + "? (Y/N)")
      if confirm.lower() == "y":
        print(code_client)
        mycursor.execute("UPDATE PERSONNE SET nom = 'inconnu', adresse_mail = 'Suprimer@gmail.com', telephone = 0 WHERE code_client = %s", (code_client,))
        mydb.commit()
        print("Client was successfully deleted.")
      else:
        print("Deletion cancelled.")


    elif num == 4:
        menu_principal3 = False
        menu_pile2.pop()  # Retirer le sous-menu bruge de la pile pour revenir au menu précédent
        break
    else :
      print("Deletion Cancelled. ")
        
    choix_retour3 = input("Voulez-vous revenir en arriere ? (Oui/Non) : ")
    if choix_retour3.lower() != "oui":
      menu_principal3 = False

    print('\n-----------------------------------\n')

def compta():
    id_user = input("Veuillez rentrer votre matricule: ")

    mycursor.execute("SELECT * FROM RESPONSABLE WHERE matricule_per = %s ", (id_user,))
    id_isthere = mycursor.fetchall()

    if id_isthere:
        #mycursor.execute("GRANT all privileges ON COMPTA_ACHAT TO %s", (id_user,))
        #mycursor.execute("GRANT all privileges ON EMPRUNT TO %s", (id_user,))
        
        choix = input("Voulez vous consulter le chiffre d'affaire annuel ou mensuel ? ")
        if choix == "annuel":
            year = input("Veuillez rentrer l'année du chiffre d'affaire que vous souhaitez consulter:")

            mycursor.execute("SELECT SUM(PRIX) FROM COMPTA_ACHAT WHERE YEAR(date_livraison_effective) = %s", (year,))
            somme_achat = mycursor.fetchone()[0] or 0  # Vérification si None, sinon utilise 0

            mycursor.execute("SELECT SUM(caution) FROM EMPRUNT WHERE YEAR(date_retour_effective) = %s", (year,))
            somme_emprunt = mycursor.fetchone()[0] or 0  # Vérification si None, sinon utilise 0

            print("Le chiffre d'affaire de l'année {} est de {} £".format(year, somme_achat + somme_emprunt))
        else:
            mois = input("Veuillez choisir un chiffre allant de 01 à 12 correspondant au mois du chiffre d'affaire que vous souhaitez consulter: ")

            mycursor.execute("SELECT SUM(PRIX) FROM COMPTA_ACHAT WHERE MONTH(date_livraison_effective) = %s", (mois,))
            somme_achat = mycursor.fetchone()[0] or 0  # Vérification si None, sinon utilise 0

            mycursor.execute("SELECT SUM(caution) FROM EMPRUNT WHERE MONTH(date_retour_effective) = %s", (mois,))
            somme_emprunt = mycursor.fetchone()[0] or 0  # Vérification si None, sinon utilise 0

            print("Le chiffre d'affaire du mois {} est de {} £".format(mois, somme_achat + somme_emprunt))
    else:
        print("Désolé, vous n'avez pas accès à la comptabilité")

def menu(titre):
    longueur = len(titre)
    ligne_superieure = "*" * (longueur + 4)
    ligne_inferieure = "*" * (longueur + 4)
    espace_vide = "* " + " " * longueur + " *"
    titre_encadre = "* " + titre + " *"

    print("\t\t"+ligne_superieure)
    print("\t\t"+espace_vide)
    print("\t\t"+titre_encadre)
    print("\t\t"+espace_vide)
    print("\t\t"+ligne_inferieure)


menu_principal = True
menu_pile=[]
while menu_principal:
  menu("BIENVENUE DANS WEDDING EXPRESS")
  print("1-->INSCRIRE CLIENT\n")
  print("2-->ACTIONS DU CLIENT\n")
  print("3-->COMPTABILITE\n")
  print("4-->QUITTER\n")

  choix=''
  while choix not in ['1', '2', '3','4']:
    choix= input("entrez votre choix\n")
    if choix=='1':  
        register()
    elif choix=='2':
        
        code_client= input("entrez votre code client: ")
        mycursor.execute("SELECT * FROM CLIENT")
        liste_client= mycursor.fetchall()
        if ("{}".format(code_client) ,) in liste_client:
            
            menu_pile.append('2')
            
            menu_pile2=[]
            menu_principal2=True
            while menu_principal2:
              print("1-->ACHAT\n")
              print("2-->EMPRUNT\n")
              print("3-->REMBOURSEMENT\n")
              print("4-->RETOUR\n")
              print("5-->VOIR OU METTRE A JOUR COORDONNEES CLIENT\n")
              print("6-->vers le menu precendent\n")
              
              choix2=''
              while choix2 not in ['1', '2', '3','4', '5','6']:
                choix2 = input("entrez votre choix: ")
                if choix2=='1':  
                    commande()
                elif choix2=='2':
                    emprunt()
                elif choix2=='3':
                    remboursement()
                    
                elif choix2=='4':
                    retour_emprunt()
                elif choix2=='5':
                    menu_pile2.append('5')
                    client_data()
                                 
                elif choix2 == '6':
                    menu_principal2 = False
                    menu_pile.pop()  # Retirer le sous-menu menu_principal2 de la pile pour revenir au menu précédent
                    break
                  
                  
              choix_retour2 = input("Voulez-vous revenir en arriere? (Oui/Non) : ")
              if choix_retour2.lower() != "oui":
                menu_principal2 = False
              
                
        else:
            print('Vous n êtes pas encore inscrit, veuillez le faire en choisissant l option 1')
            
    elif choix=='3':          
        compta()
    elif choix=='4':
      print("AUREVOIR!")
      sys.exit()
  
  choix_retour = input("Voulez-vous revenir au menu principal ? (Oui/Non) : ")
  if choix_retour.lower() != "oui":
    menu_principal = False

  print('\n-----------------------------------\n')
    

